import React, { useState } from "react";

function App() {
  const [phoneNumber, setPhoneNumber] = useState("");
  const [amount, setAmount] = useState("");
  const [message, setMessage] = useState("");

  const handlePay = async () => {
    if (!phoneNumber || !amount) {
      setMessage("Please enter both phone number and amount.");
      return;
    }

    setMessage("Processing payment...");

    try {
      const response = await fetch("/api/pesapal/initiate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ phoneNumber, amount }),
      });

      const data = await response.json();

      if (data.status === "success") {
        setMessage(`Payment initiated. Transaction ID: ${data.transactionId}`);
      } else {
        setMessage("Payment failed.");
      }
    } catch (error) {
      console.error("Payment Error:", error);
      setMessage("Error while initiating payment.");
    }
  };

  return (
    <div style={{ padding: "2rem", maxWidth: "400px", margin: "auto" }}>
      <h2>E-Payment - Kenya</h2>
      <div style={{ marginBottom: "1rem" }}>
        <input
          type="text"
          placeholder="Phone Number"
          value={phoneNumber}
          onChange={(e) => setPhoneNumber(e.target.value)}
          style={{ width: "100%", padding: "0.5rem" }}
        />
      </div>
      <div style={{ marginBottom: "1rem" }}>
        <input
          type="number"
          placeholder="Amount (KES)"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          style={{ width: "100%", padding: "0.5rem" }}
        />
      </div>
      <button onClick={handlePay} style={{ padding: "0.5rem 1rem" }}>
        Pay Now
      </button>
      <div style={{ marginTop: "1rem" }}>
        <strong>{message}</strong>
      </div>
    </div>
  );
}

export default App;
