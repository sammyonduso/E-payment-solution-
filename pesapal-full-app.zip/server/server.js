const express = require("express");
const axios = require("axios");
const crypto = require("crypto");
const dotenv = require("dotenv");

dotenv.config();
const app = express();

app.use(express.json());

const consumerKey = process.env.PESAPAL_CONSUMER_KEY;
const consumerSecret = process.env.PESAPAL_CONSUMER_SECRET;

let accessToken = "";

// Get OAuth 2.0 token
app.get("/api/pesapal/token", async (req, res) => {
  try {
    const credentials = Buffer.from(`${consumerKey}:${consumerSecret}`).toString("base64");
    const response = await axios.post(
      "https://cybqa.pesapal.com/v3/api/Auth/RequestToken",
      {},
      {
        headers: {
          Authorization: `Basic ${credentials}`,
          Accept: "application/json",
        },
      }
    );

    accessToken = response.data.token;
    console.log("Access Token:", accessToken);
    res.json({ token: accessToken });
  } catch (error) {
    console.error("Pesapal Token Error:", error.response?.data || error);
    res.status(500).json({ error: "Failed to fetch Pesapal token" });
  }
});

// Initiate a payment request
app.post("/api/pesapal/initiate", async (req, res) => {
  const { phoneNumber, amount } = req.body;

  try {
    const paymentData = {
      id: crypto.randomUUID(),
      currency: "KES",
      amount: parseFloat(amount),
      description: "Payment via web",
      callback_url: "https://your-site.com/callback",
      notification_id: "your-notification-id",
      billing_address: {
        phone_number: phoneNumber,
        email_address: "user@example.com",
        country_code: "KE",
        first_name: "John",
        last_name: "Doe",
        line_1: "Nairobi",
        city: "Nairobi",
        state: "Nairobi",
        postal_code: "00100",
        zip_code: "00100",
      },
    };

    const response = await axios.post(
      "https://cybqa.pesapal.com/v3/api/Transactions/SubmitOrderRequest",
      paymentData,
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          Accept: "application/json",
          "Content-Type": "application/json",
        },
      }
    );

    console.log("Payment Response:", response.data);
    res.json({ status: "success", transactionId: response.data.order_tracking_id });
  } catch (error) {
    console.error("Payment Initiation Error:", error.response?.data || error);
    res.status(500).json({ error: "Payment initiation failed" });
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
